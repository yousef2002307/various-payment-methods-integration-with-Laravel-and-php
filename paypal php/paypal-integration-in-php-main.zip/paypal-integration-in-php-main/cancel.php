<?php
include('PaypalHelper.php');
$paypal = new Paypal(); // create objet from helper paypal
$paymentId = $_GET['paymentId']??"";
{
       // payment failed 
}